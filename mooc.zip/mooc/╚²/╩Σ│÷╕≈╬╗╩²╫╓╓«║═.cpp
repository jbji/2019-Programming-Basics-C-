#include <stdio.h>
typedef long long LL;
int a[100];
int work(int n){
	if(!n) return 0;
	else return work(n/10)+n%10;
}
int main(){
	int n;
	scanf("%d",&n);
	printf("%d\n",work(n));
	
	return 0;
}
