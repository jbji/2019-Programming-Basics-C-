#include <stdio.h>
typedef long long LL;
LL work(int x,int step){
	if(x==1) return printf("1\n"),step;
	else{
		printf("%d,",x);
		if(x&1) return work(x*3+1,step+1);
		else return work(x/2,step+1);
	}
}
int main(){
	int n;
	scanf("%d",&n);
	printf("step=%d\n",work(n,1));
	return 0;
}
