#include <stdio.h>
typedef long long LL;
int a[100];
int work(int num){
	if(num==0) return 2;
	else{
		int tmp=work(num-1);
		a[num]=tmp+2;
		return (tmp+1)*2;
	}
		
}
int main(){
	int sum=work(7);
	printf("sum=%d\n",sum);
	int i;
	for(i=7; i>=1; i--) printf("sell=%d,",a[i]);
	printf("\n");
	return 0;
}
