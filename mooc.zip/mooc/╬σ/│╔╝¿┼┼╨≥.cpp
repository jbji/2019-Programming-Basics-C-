#include <stdio.h>
#include <stdlib.h>
int a[5][5],b[5];
int cmp(const void *i,const void *j){
	return *(int *)j- *(int *) i;
}
int f[5];
int main(){
	int i,j;
	for(i=1; i<=3; i++){
		for(j=1; j<=4; j++){
			scanf("%d",&a[i][j]);b[i]+=a[i][j];
		}
	}
	for(i=1; i<=3; i++){
		int max=0,p;
		for(j=1; j<=3; j++){
			if(b[j]>max && !f[j]){
				max=b[j]; p=j;
			}
		}
		f[p]=1;
		for(j=1; j<=3; j++){
			printf("%d,",a[p][j]);
		}
		printf("%d\n",a[p][4]);
	}
	return 0;
}
