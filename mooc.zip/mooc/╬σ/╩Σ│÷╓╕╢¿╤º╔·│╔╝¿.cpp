#include <stdlib.h> 
#include <stdio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */   
int main()
{
	int a[3+1][4];
	int i,n,m,j;
	int (*p)[4];
	int sum=0;
	p=a;
	for(i=0;i<3;i++)
	  for(j=0;j<4;j++)
	  {scanf("%d",&a[i][j]);}
	scanf("%d",&n);
	n=n-1;
	for(i=0;i<3;i++)
    {
    	printf("%d ",(*(*(p+n)+i)));
	}
	printf("%d",(*(*(p+n)+3)));
	printf("\n");
	for(i=0;i<4;i++)
	{
		sum=sum+(*(*(p+n)+i));
	}
	if(sum%4==0){
		printf("%d\n",sum/4); return 0;
	}
	printf("%.2f\n",sum*1.0/4);
	return (0);
}
