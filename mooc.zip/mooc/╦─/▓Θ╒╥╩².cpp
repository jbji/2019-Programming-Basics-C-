#include <stdio.h>
#include <string.h>
int a[100];
int *b,c;
int main(){
	int i;
	for(i=1; i<=10; i++){
		scanf("%d",&a[i]);
	}
	scanf("%d",&c);
	b=a;
	for(i=1; i<=10; i++){
		if(*(b+i)==c){
			printf("%d\n",c); return 0;
		}
	}
	printf("No\n");
	return 0;
}
