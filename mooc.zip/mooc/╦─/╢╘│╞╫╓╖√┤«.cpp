#include <string.h>
#include <stdio.h>

char s[100000];
int main(){
	
	gets(s);
	int len=strlen(s);
	int i;
	char *start,*end;
	start=s; end=s+len-1;
	for(i=0; i<len; i++){
		if(*start!=*end){
			printf("NO\n"); return 0;
		}
		start++; end--;
	}
	printf("YES\n");
	return 0;
}
