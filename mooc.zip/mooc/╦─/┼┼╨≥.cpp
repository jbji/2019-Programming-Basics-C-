#include <string.h>
#include <stdio.h>
#include <stdlib.h>
int b[1000];
int *a;
int main(){
	int i,j;
	for(i=1; i<=10; i++){
		scanf("%d",&b[i]);
	}
	a=b;
	for(i=2; i<=10; i++){
		int tmp=*(a+i);
		for(j=i-1; j>=1; j--){
			if(*(a+j)>tmp) *(a+j+1)=*(a+j);
			else break;
		}
		*(a+j+1)=tmp;
	}
	for(i=1; i<=10; i++){
		i==10? printf("%d\n",*(a+i)):printf("%d,",*(a+i));
	}
	return 0;
}
