#include <stdio.h>
#include <string.h>
char s[10000];
char ans[1000];
int main(){
	gets(s);
	int len=strlen(s),i;
	for(i=0; i<len; i++){
		if(s[i]=='n'){
			int k=strlen(ans);
			if(!k) continue;
			puts(ans);
			memset(ans,0,sizeof(ans));
		}
		else{
			sprintf(ans,"%s%c",ans,s[i]);
		}
	}
	len=strlen(ans);
	if(len){
		puts(ans);
	}
	
	return 0;
}
