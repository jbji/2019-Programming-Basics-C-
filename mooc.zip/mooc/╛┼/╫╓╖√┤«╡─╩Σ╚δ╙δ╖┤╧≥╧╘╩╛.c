#include <stdio.h>
#include <string.h>
void work(){
	char ch=getchar();
	if(ch=='\n') return;
	work();
	putchar(ch);
}
int main(){
	work();
	printf("\n"); 
	return 0;
}
