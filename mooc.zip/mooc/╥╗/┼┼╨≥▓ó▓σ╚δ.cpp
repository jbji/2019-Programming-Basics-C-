#include <stdio.h>
typedef long long LL;
int a[20];
int Insert(int num,int x){
	int i;
	for(i=num-1; i>=1; i--){
		if(a[i]>x) a[i+1]=a[i];
		else break; 
	}
	a[i+1]=x;
	return 0;
}
int main(){
	int i;
	for(i=1; i<=8; i++){
		scanf("%d,",&a[i]);
	}
	scanf("%d",&a[i]);
	for(i=1; i<=9; i++) Insert(i,a[i]);
	scanf("%d",&a[10]);
	Insert(10,a[10]);
	for(i=1; i<=10; i++){
		i==10?printf("%d\n",a[i]):printf("%d,",a[i]);
	} 
	return 0;
}
