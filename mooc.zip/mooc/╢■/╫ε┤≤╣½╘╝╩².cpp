#include <stdio.h>
typedef long long LL;
LL gcd(LL x,LL y){
	return x%y==0?y:gcd(y,x%y);
}
int main(){
	LL n,m;
	scanf("%lld,%lld",&n,&m);
	printf("%lld\n",gcd(n,m));
	return 0;
}
