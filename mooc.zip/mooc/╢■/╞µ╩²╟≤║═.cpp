#include <stdio.h>
typedef long long LL;
LL work(int x){
	if(x==1) return 1;
	return work(x-2)+x;
}
int main(){
	int n;
	scanf("%d",&n);
	printf("%lld\n",work(2*n-1));
	return 0;
} 
