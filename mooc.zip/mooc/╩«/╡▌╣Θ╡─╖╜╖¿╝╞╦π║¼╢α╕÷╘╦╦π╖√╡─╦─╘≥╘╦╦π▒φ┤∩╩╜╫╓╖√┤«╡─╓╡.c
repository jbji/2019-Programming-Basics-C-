#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int s[10000],cnt;
void work(){
	char ch;
	scanf("%c",&ch);
	if(ch!='/' && ch!='*' && ch!='-' && ch!='+') return;
	int p;
	scanf("%d",&p);
	if(ch=='*') s[cnt]*=p;
	else if(ch=='/') s[cnt]/=p;
	else{
		s[++cnt]=p;
	}
	work();
	if(ch=='+'){
		s[--cnt]+=s[cnt+1];
	}
	else if(ch=='-'){
		s[--cnt]-=s[cnt+1];
	}
}
int main(){
	int ans1;
	scanf("%d",&ans1);
	s[++cnt]=ans1;
	work();
	printf("%d\n",s[cnt]);
	return 0;
}
