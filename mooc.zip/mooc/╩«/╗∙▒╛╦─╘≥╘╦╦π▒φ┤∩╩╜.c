#include <stdio.h>
#include <stdlib.h>
#include <string.h>
long long ans1,ans2;
char f,c;
int main(){
	scanf("%lld",&ans1);
	while(c!='/' && c!='*' && c!='-' && c!='+') scanf("%c",&c);
	f=c;
	scanf("%lld",&ans2);
	long long ans=0;
	switch(f){
		case '+':ans=ans1+ans2; break;
		case '-': ans=ans1-ans2; break;
		case '*': ans=ans1*ans2; break;
		case '/': printf("%lld\n",ans1/ans2); return 0;
	}
	printf("%lld\n",ans);
	return 0;
}
