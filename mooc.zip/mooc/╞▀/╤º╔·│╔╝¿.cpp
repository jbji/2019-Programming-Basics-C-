#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char s[1000];
int a[1000];
int main(){
	a[1]=80; a[2]=85; a[3]=79;
	gets(s);
	int len=strlen(s);
	if(len==1){
		int p=s[0]-'0';
		if(p>0 && p<=3){
			printf("%d\n",a[p]);
		}
		else{
			printf("0\n");
		}
	}
	else{
		if(strcmp("max",s)==0){
			printf("2\n");
		}
		else{
			printf("0\n");
		}
	}
	return 0;
}
