#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char s[1000],s1[10000];
int ans;
int main(){
	s['a']='d'; s['b']='w'; s['c']='k'; s['d']=';';
	s['e']='i'; s['i']='a'; s['k']='b'; s[';']='c'; s['w']='e';
	gets(s1);
	int i,len=strlen(s1);
	for(i=0; i<len; i++){
		if(s[s1[i]]){
			printf("%c",s[s1[i]]);
		}
		else{
			printf("%c",s1[i]);
		}
	}
	printf("\n");
	return 0;
}
