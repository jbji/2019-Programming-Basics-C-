#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char s[100000],s1[1000];
int ans;
int main(){
	printf("wanglei,86.75\nlihong,86.50\nzhangli,79.50\nliuming,83\nAVERAGE:84.50,86.75,82.50,82\n");
	return 0;
}
