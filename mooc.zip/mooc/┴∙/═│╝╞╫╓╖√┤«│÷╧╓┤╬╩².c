#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char s[100000],s1[1000];
int ans;
int main(){
	gets(s); gets(s1);
	int i=0,j=0,len1=strlen(s),len2=strlen(s1);
	for(i=0; i<len1; i++){
		for(j=0; j<len2; j++){
			if(s[i+j]!=s1[j]) break;
		}
		if(j==len2){
			ans++;
		}
	}
	if(ans)
		printf("%d\n",ans);
	else
		printf("No\n");
	return 0;
}
