#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct node{
	char id;
	struct node *nxt;
}N;
N *head[2],*tail[2];
char s[100000],ans[100000],cnt;
int f[10000];
int main(){
	int i,k;
	for(k=0; k<=1; k++){
		gets(s);
		head[k]=(N*)malloc(sizeof(N));
		head[k]->nxt=NULL; tail[k]=head[k];
		int len=strlen(s);
		for(i=0; i<len; i++){
			if(s[i]!=' '){
				tail[k]->nxt=(N*)malloc(sizeof(N));
				tail[k]->nxt->id=s[i];
				tail[k]=tail[k]->nxt;
				tail[k]->nxt=NULL;
			}
		}
	}
	N *p1=head[0]->nxt,*p2=head[1]->nxt;
	while(p1 && p2){
		char tmp;
		if(p1->id<p2->id){
			tmp=p1->id; N *del=p1; p1=p1->nxt; free(del);
		}else{
			tmp=p2->id; N *del=p2; p2=p2->nxt; free(del);
		}
		if(!f[tmp]){
			f[tmp]=1;
			ans[++cnt]=tmp;
		}
	}
	if(!p1) p1=p2;
	while(p1){
		if(!f[p1->id]){
			f[p1->id]=1;
			ans[++cnt]=p1->id;
		}
		N *del=p1; 
		p1=p1->nxt;
		free(del);
	}
	for(i=1; i<cnt; i++){
		printf("%c ",ans[i]);
	}
	printf("%c\n",ans[cnt]);
	free(head[0]); free(head[1]);
	return 0;
}
