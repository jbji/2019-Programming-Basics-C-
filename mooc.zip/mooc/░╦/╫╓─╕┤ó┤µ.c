#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char s[1000];
int a[1000];
int main(){
	s['0']='a'; s['1']='b'; s['2']='c'; s['3']='d'; s['4']='c';
	s['5']='b'; s['6']='a';
	s['a']='6'; s['b']='5'; s['c']='4'; s['d']='3';
	char ch;
	scanf("%c",&ch);
	if(s[ch]){
		printf("%c\n",s[ch]);
	}
	else{
		printf("N\n");
	}
	return 0;
}
